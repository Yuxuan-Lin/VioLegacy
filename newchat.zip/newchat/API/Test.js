const express = require('express');
const path = require('path');
const data = require('./data/data.json');
const cors = require('cors');

const app = express();

app.use(cors());

app.get('/', (req,res,next) => {
    console.log('welcome')});
app.get('/data', (req,res, next) => {
    res.send(data);
    console.log('data accessed');
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {console.log('Server Started!')});