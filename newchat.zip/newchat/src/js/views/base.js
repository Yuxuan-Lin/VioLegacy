export const elements = {
    contactList: document.querySelector('.contact-list'),
    chatHistory: document.querySelector('.chat-history'),
    profile: document.querySelector('.profile'),
    tools: document.querySelector('.tools')
};