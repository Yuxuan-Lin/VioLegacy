import Contacts from './models/contacts';
import Chat from './models/chat';
import {elements} from './views/base';
import * as contactsView from './views/contactsView'; 
import * as chatView from './views/chatView';



const state = {};
state.contacts = new Contacts("chat");
state.image = "../images/kerwin.jpg";


const controlContacts = async () => {
    //1) Get contact list(array)
    
    await state.contacts.getContacts();
    
    //2) Prepare UI(optional)

    //3) Render contacts on UI
    contactsView.renderContacts(state.contacts.result);


    //1) Get chatHistory(array) and profile

    //2) Prepare UI(clear field)

    //3) Render chatHistroy and profile on UI
    
    
    
}

const controlChat = async (id=0) => {
    // render Profile UI
    await state.contacts.getContacts();
    chatView.renderProfile(state.contacts.result[id]);
    
    // render Chat UI
    chatView.renderChats(state.contacts.result[id].profile.image, state.image, state.contacts.result[id].chatHistory);
};

elements.contactList.addEventListener('click', e => {
    const btn = e.target.closest('.contact-person').id;
    if (btn) {
        chatView.clearChat();
        controlChat(btn);
        //searchView.clearResults();
        //searchView.renderResults(state.search.result, goToPage);
    }
});


controlContacts();
controlChat();

elements.tools.addEventListener('click', e => {
    e.preventDefault();
    const tab = e.target.closest('.tab');
    tabSwitch(tab);
    
});

const tabSwitch = function (tab){
    const id = parseInt(tab.parentNode.id);
    console.log(id);
    if (id != 0 && id != 4){
        //clear
        let markup = tab.parentNode.parentNode.childNodes;
        console.log(markup);
        for (let i=1; i<11; i=i+2){
            markup[i].classList = [];
            markup[i].childNodes[1].classList = ['tab'];
        }

        //above selected change
        markup[1 + (parseInt(tab.parentNode.id) - 1) * 2].classList.add('above-selected');
        markup[1 + (parseInt(tab.parentNode.id) - 1) * 2].childNodes[1].classList.add('special-tab-1');

        //selected tab change
        tab.parentNode.classList.add('selected-tab');

        //below selected change
        markup[1 + (parseInt(tab.parentNode.id) + 1) * 2].classList.add('below-selected');
        markup[1 + (parseInt(tab.parentNode.id) + 1) * 2].childNodes[1].classList.add('special-tab-2');
    }
};

